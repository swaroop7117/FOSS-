package medicell.com.rit.Live;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;

import medicell.com.rit.R;

/**
 * Created by Swaroop on 03-02-2018.
 */

public class live extends AppCompatActivity{

    VideoView videoView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.live);

        videoView=findViewById(R.id.livevideo);
        MediaController mediaController= new MediaController(this);
        mediaController.setAnchorView(videoView);

    }
}
