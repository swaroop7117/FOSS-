package medicell.com.rit.fab;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;

import medicell.com.rit.PostReq.MailActivity;
import medicell.com.rit.R;

/**
 * Created by Swaroop on 06-01-2018.
 */

public class Fab extends AppCompatActivity {

    FloatingActionMenu floatingActionMenu;
    FloatingActionButton floatingActionButton1, floatingActionButton2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fabutton);

        floatingActionMenu = (FloatingActionMenu) findViewById(R.id.material_design_android_floating_action_menu);
       // floatingActionButton1 = (FloatingActionButton) findViewById(R.id.material_design_android_floating_action_menu);


     /*   floatingActionButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Fab.this, MailActivity.class);
                startActivity(intent);

                Toast.makeText(Fab.this, "Post", Toast.LENGTH_LONG).show();
            }
        });*/

    }
}