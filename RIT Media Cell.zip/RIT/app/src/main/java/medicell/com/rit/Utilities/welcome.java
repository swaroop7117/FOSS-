package medicell.com.rit.Utilities;


import android.content.Intent;
        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.Window;
        import android.view.WindowManager;
        import android.widget.ImageView;

        import com.squareup.picasso.Picasso;

        import medicell.com.rit.Home.HomeActivity;
        import medicell.com.rit.R;

public class welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Picasso.with(getApplicationContext()).load(R.drawable.bridge).into((ImageView)findViewById(R.id.imageView4));

        SharedPreferences.Editor editor = getSharedPreferences("hs", MODE_PRIVATE).edit();
        editor.putString("time","10");
        editor.commit();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Thread mythread=new Thread(){
            @Override
            public void run() {
                try {
                    sleep(1500);
                    Intent in=new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(in);
                    finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        mythread.start();
    }
}
