package medicell.com.rit.extras;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import medicell.com.rit.Home.HomeActivity;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.R;

/**
 * Created by Swaroop on 10-01-2018.
 */

public class feedback extends AppCompatActivity {

    ImageButton button;
    Button btn;
    EditText textMessage;
    TextView t1;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feedback);
        //setContentView(R.layout.header);

        button=(ImageButton) findViewById(R.id.imgbtn14);
        btn=(Button) findViewById(R.id.sendbtn2);
        textMessage = (EditText) findViewById(R.id.t1);
        t1= findViewById(R.id.text_txt5);
        final String s1="Feedback";
        t1.setText(s1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(feedback.this, Extra.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
                finishAffinity();
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String to = "mediacell@ritindia.edu";
                String subject = "Feedback Of App";
                String message = textMessage.getText().toString();

                Intent email = new Intent(Intent.ACTION_SEND);
                email.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                //email.putExtra(Intent.EXTRA_CC, new String[]{ to});
                //email.putExtra(Intent.EXTRA_BCC, new String[]{to});
                email.putExtra(Intent.EXTRA_SUBJECT, subject);
                email.putExtra(Intent.EXTRA_TEXT, message);
                //need this to prompts email client only
                email.setType("message/rfc822");
                startActivity(Intent.createChooser(email, "Choose an Email client :"));
            }
        });
    }

}
