package medicell.com.rit.PostReq;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.ImageButton;

import medicell.com.rit.R;
import medicell.com.rit.extras.Extra;
import medicell.com.rit.extras.feedback;

/**
 * Created by Swaroop on 08-01-2018.
 */


public class MailActivity extends AppCompatActivity {
    Button buttonSend;
  //  EditText textTo;
   // EditText textSubject;
    EditText textMessage;
    ImageButton button;
    Checkable c1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail);

        buttonSend = (Button) findViewById(R.id.sendbtn);
        // textTo = (EditText)findViewById(R.id.editTextTo);
        //textSubject = (EditText)findViewById(R.id.editTextSubject);
        textMessage = (EditText) findViewById(R.id.EditText8);

        button=(ImageButton) findViewById(R.id.imgbtn15);
        c1=(CheckBox) findViewById(R.id.check1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MailActivity.this, Extra.class);
                startActivity(intent);
                finishAffinity();
            }
        });


          buttonSend.setOnClickListener(new View.OnClickListener() {

              @Override
              public void onClick(View v) {

                  if (c1.isChecked()) {
                      String to = "mediacell@ritindia.edu";
                      String subject = "CONTENT REQUEST";
                      String message = textMessage.getText().toString();

                      Intent email = new Intent(Intent.ACTION_SEND);
                      email.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                      //email.putExtra(Intent.EXTRA_CC, new String[]{ to});
                      //email.putExtra(Intent.EXTRA_BCC, new String[]{to});
                      email.putExtra(Intent.EXTRA_SUBJECT, subject);
                      email.putExtra(Intent.EXTRA_TEXT, message);
                      //need this to prompts email client only
                      email.setType("message/rfc822");
                      startActivity(Intent.createChooser(email, "Choose an Email client :"));

                  }
              }
          });

    }
}
