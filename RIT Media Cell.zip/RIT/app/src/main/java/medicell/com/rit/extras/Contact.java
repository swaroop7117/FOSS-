package medicell.com.rit.extras;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

import medicell.com.rit.Home.HomeActivity;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.R;

/**
 * Created by Swaroop on 10-01-2018.
 */

public class Contact extends AppCompatActivity {

    ImageButton button;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feedback);

        button=(ImageButton) findViewById(R.id.imgbtn10);

    }
}
