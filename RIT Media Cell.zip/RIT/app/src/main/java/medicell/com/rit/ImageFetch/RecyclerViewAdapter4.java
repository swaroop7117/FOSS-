package medicell.com.rit.ImageFetch;

/**
 * Created by Swaroop on 15-01-2018.
 */

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;

import medicell.com.rit.Clubs.Clubpage;
import medicell.com.rit.Clubs.clubs;
import medicell.com.rit.ImageUpload.ClubsUpload;
import medicell.com.rit.ImageUpload.ImageUpload;
import medicell.com.rit.ImageUpload.NoticeUpload;
import medicell.com.rit.ImageUpload.TextUpload;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.R;

/**
 * Created by AndroidJSon.com on 6/18/2017.
 */

public class RecyclerViewAdapter4 extends RecyclerView.Adapter<RecyclerViewAdapter4.ViewHolder> {

    Context context;
    List<ClubsUpload> MainClubsUploadList;



    public RecyclerViewAdapter4(Context context, List<ClubsUpload> TempList) {

        this.MainClubsUploadList = TempList;

        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.clubpagetext, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);



        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final ClubsUpload UploadInfo = MainClubsUploadList.get(position);

        holder.name.setText(UploadInfo.Name());

        final String a= UploadInfo.Url();
        final String b= UploadInfo.Name();
        final String c= UploadInfo.Description();
//       holder.text.setText(UploadInfo.getName3());

        holder.name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Intent intent= new Intent()
                Intent intent= new Intent(context, clubs.class);

                Bundle bundle = new Bundle();
                bundle.putString("url", a);
                bundle.putString("name",b);
                bundle.putString("description",c);

                intent.putExtras(bundle);

                context.startActivity(intent);

//                holder.name2.setText(UploadInfo.Name());
//                Glide.with(context).load(UploadInfo.Url()).into(holder.image);
//                holder.description.setText(UploadInfo.Description());
            }
        });

        //Loading image from Glide library.

    }

    @Override
    public int getItemCount() {

        return MainClubsUploadList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public TextView name2;
        public TextView description;
        public ImageView image;


        public ViewHolder(View itemView) {
            super(itemView);

            image= itemView.findViewById(R.id.imageofclubs);
            name = itemView.findViewById(R.id.clubname);
            name2= itemView.findViewById(R.id.nameofclub);
            description = itemView.findViewById(R.id.infoofclub);


        }

    }


}
