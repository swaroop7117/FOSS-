package medicell.com.rit.News;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.clans.fab.FloatingActionMenu;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import java.util.ArrayList;
import java.util.List;

import medicell.com.rit.ImageFetch.RecyclerViewAdapter2;
import medicell.com.rit.ImageUpload.TextUpload;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.R;
import medicell.com.rit.Utilities.BottomNavigationViewHelper;

/**
 * Created by Swaroop on 08-01-2018.
 */

public class News extends AppCompatActivity {


    private static final String TAG ="HomeActivity" ;
    protected FloatingActionMenu floatingActionMenu;
    private static final int ACTIVITY_NUM = 1;
    private Context mContext = News.this;

    private RecyclerView mRecyclerview;
    private FrameLayout mFrameLayout;
    private RelativeLayout mRelativeLayout;
    protected ImageButton button2;
    public static final String Database_Path = "Text_data";

    FirebaseStorage storage;
    private TextView text;
    private StorageReference mStorage;



    // Creating DatabaseReference.
    DatabaseReference databaseReference;

    // Creating RecyclerView.
    RecyclerView recyclerView;

    // Creating RecyclerView.Adapter.
    RecyclerView.Adapter adapter ;

    // Creating Progress dialog
    ProgressDialog progressDialog;

    // Creating List of ImageUploadInfo class.
    List<TextUpload> list = new ArrayList<>();
    List<TextUpload> list2= new ArrayList<>();





    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);


        // mRelativeLayout = (RelativeLayout) findViewById(R.id.relLayoutParent);
//        text = (TextView) findViewById(R.id.post_);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView2);

        // Setting RecyclerView size true.
        recyclerView.setHasFixedSize(true);

        // Setting RecyclerView layout as LinearLayout.
        recyclerView.setLayoutManager(new LinearLayoutManager(News.this));

        // Assign activity this to progress dialog.

        progressDialog = new ProgressDialog(News.this);

        // Setting up message in Progress dialog.
        progressDialog.setMessage("Loading...");

        // Showing progress dialog.
        progressDialog.show();

        // Setting up Firebase image upload folder path in databaseReference.
        // The path is already defined in MainActivity.
        databaseReference = FirebaseDatabase.getInstance().getReference(News.Database_Path);

        floatingActionMenu = (FloatingActionMenu) findViewById(R.id.material_design_android_floating_action_menu);
        button2 = (ImageButton) findViewById(R.id.imgbtn1);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(News.this, Notifications.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);

            }
        });


//        floatingActionMenu.setOnMenuButtonClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(News.this, MailActivity.class);
//                startActivity(intent);
//            }
//        });


        // Adding Add Value Event Listener to databaseReference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                    TextUpload textUpload = postSnapshot.getValue(TextUpload.class);

                    list.add(textUpload);


                }
                int cnt=list.size();

                for(int i=cnt;i>0;i--)
                {
                    list2.add(list.get(i-1));
                }


                adapter = new RecyclerViewAdapter2(getApplicationContext(), list2);
                recyclerView.setAdapter(adapter);

                // Hiding the progress dialog.
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                // Hiding the progress dialog.
                progressDialog.dismiss();

            }
        });


        setupBottomNavigationView();
        //  GetDataFirebase();

    }




    private void setupBottomNavigationView(){
        Log.d(TAG, "setupBottomNavigationView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(mContext, this,bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);

    }
}

