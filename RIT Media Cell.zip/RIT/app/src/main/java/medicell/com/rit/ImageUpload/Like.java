package medicell.com.rit.ImageUpload;

/**
 * Created by User on 8/21/2017.
 */

public class Like {

    private String count;
    private String like;

    public Like(String count) {
        this.count = count;
    }

    public Like() {
    }

    public String count() {
        return count;
    }

    public void setLike(String like) {
        this.like = like;
    }

}
