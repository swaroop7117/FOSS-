package medicell.com.rit.ImageUpload;

/**
 * Created by Swaroop on 16-01-2018.
 */

public class NoticeUpload {

    public String textName;
    public String textdata;

    public String getName2() {
        return textName;
    }

    public String getName3() {
        return textdata;
    }

    public NoticeUpload(String textname, String textdata) {
        this.textName = textname;
        this.textdata = textdata;
    }

    public NoticeUpload(){}
}
