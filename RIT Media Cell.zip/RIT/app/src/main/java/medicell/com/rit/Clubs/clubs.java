package medicell.com.rit.Clubs;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import medicell.com.rit.ImageFetch.RecyclerViewAdapter;
import medicell.com.rit.ImageFetch.RecyclerViewAdapter4;
import medicell.com.rit.ImageUpload.ClubsUpload;
import medicell.com.rit.R;

/**
 * Created by Swaroop on 30-01-2018.
 */

public class clubs extends AppCompatActivity  {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.club);

        ImageView img = findViewById(R.id.imageofclubs);
        TextView txt = findViewById(R.id.nameofclub);
        TextView txt2 = findViewById(R.id.infoofclub);

        Bundle bundle = getIntent().getExtras();
        txt.setText(bundle.getCharSequence("name"));
        txt2.setText(bundle.getCharSequence("description"));


        final String IMAGE_URL1= (String) bundle.getCharSequence("url");

        Picasso
                .with(this)
                .load(IMAGE_URL1)
                .into(img);
    }
}
