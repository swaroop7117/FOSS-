package medicell.com.rit.extras;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import medicell.com.rit.R;

/**
 * Created by Swaroop on 10-01-2018.
 */

public class Settings extends AppCompatActivity {


    private static final String TAG = "Settings";
    ImageButton btn;
    TextView txt;
    Switch s1,s2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        btn=(ImageButton) findViewById(R.id.imgbtn11);

        s1=(Switch) findViewById(R.id.switch1);
        s2=(Switch) findViewById(R.id.switch2);

        TextView t1= findViewById(R.id.text_txt5);
        final String s="Settings";
        t1.setText(s);

        txt=(TextView) findViewById(R.id.t7);

        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Log.d(TAG, "onClick: navigating to about us screen");
                Intent intent = new Intent(Settings.this, Calender.class);
                startActivity(intent);*/

                Intent ringtone = new Intent(Intent.ACTION_GET_CONTENT);
             /*   email.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                //email.putExtra(Intent.EXTRA_CC, new String[]{ to});
                //email.putExtra(Intent.EXTRA_BCC, new String[]{to});
                email.putExtra(Intent.EXTRA_SUBJECT, subject);
                email.putExtra(Intent.EXTRA_TEXT, message);
                //need this to prompts email client only*/
                ringtone.setType("ringtone/*");
                startActivity(Intent.createChooser(ringtone, "Choose :"));
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Settings.this,Extra.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
                finishAffinity();
            }
        });

        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(Settings.this,"Enabled",Toast.LENGTH_LONG).show();
                    // The toggle is enabled
                } else {
                    Toast.makeText(Settings.this,"Disabled",Toast.LENGTH_LONG).show();
                    // The toggle is disabled
                }
            }
        });

        s2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(Settings.this,"Enabled",Toast.LENGTH_LONG).show();
                    // The toggle is enabled
                } else {
                    Toast.makeText(Settings.this,"Disabled",Toast.LENGTH_LONG).show();
                    // The toggle is disabled
                }
            }
        });
    }


}
