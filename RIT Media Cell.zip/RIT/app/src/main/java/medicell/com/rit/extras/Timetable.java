package medicell.com.rit.extras;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import medicell.com.rit.R;

/**
 * Created by Swaroop on 23-01-2018.
 */

public class Timetable extends AppCompatActivity {

    TextView t1,t2,t3,t4,header,t5,t6,t7,t8;
    ImageButton button;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timetable);

        button=findViewById(R.id.imgbtn14);

        header=findViewById(R.id.text_txt7);

        TextView t1= findViewById(R.id.text_txt5);
        final String s1="TimeTable";
        t1.setText(s1);

        t1=findViewById(R.id.tt1);
        t2=findViewById(R.id.tt2);
        t3=findViewById(R.id.tt3);
        t4=findViewById(R.id.tt4);
        t5=findViewById(R.id.tt5);
        t6=findViewById(R.id.tt6);
        t7=findViewById(R.id.tt7);
        t8=findViewById(R.id.tt8);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Timetable.this, Extra.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
                finishAffinity();
            }
        });


        t1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            String url = "https://drive.google.com/open?id=1SOSwso1npCFYk1mFSZvGRQDnRH-raS8w";
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        }
    });

        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=1o3kSNatw54HcUwu9qAOOKMim3dxgJL-g";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=1mAKjnzbhOY9FWmIYtL8Dsv7oJaXgHVK-";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=1txgiWo6kdNlHHHIx70tvdMtcW8rqaKL9";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(Timetable.this, "No Result Found...", Toast.LENGTH_SHORT).show();
                String url = "https://drive.google.com/open?id=1ThtlhrGpDk9dQJ3URkeCokzEIVMAw3EG";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        t6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=1V8FdoQGCpVD5Ga0WnC6MiDHNVyB4_UTa";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        t7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(Timetable.this, "No Result Found...", Toast.LENGTH_SHORT).show();
                String url = "https://drive.google.com/open?id=1V8FdoQGCpVD5Ga0WnC6MiDHNVyB4_UTa";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        t8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=17bqCzwFLeibFANWGgcYWhqbO3q1Ec_SH";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });


    }
}
