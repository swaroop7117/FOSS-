package medicell.com.rit.ImageUpload;

/**
 * Created by Swaroop on 16-01-2018.
 */

public class ClubsUpload {

    public String Name;
    public String url;
    public String description;

    public String Name() {
        return Name;
    }

    public String Url() {
        return url;
    }

    public String Description(){
        return description;
    }

    public ClubsUpload(String Name, String url, String description) {
        this.Name = Name;
        this.url = url;
        this.description=description;
    }

    public ClubsUpload(){}
}
