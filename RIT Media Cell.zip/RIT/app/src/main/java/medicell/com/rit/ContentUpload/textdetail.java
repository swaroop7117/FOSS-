package medicell.com.rit.ContentUpload;

/**
 * Created by Swaroop on 24-01-2018.
 */

public class textdetail {



        private String name;
        private String data;

        public textdetail() {
            // This is default constructor.
        }

        public String getTextName() {

            return name;
        }

        public void setTextName(String name) {

            this.name = name;
        }

        public String getTextdata() {

            return data;
        }

        public void setTextdata(String data) {

            this.data= data;
        }


}

