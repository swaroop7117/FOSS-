package medicell.com.rit.extras;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import medicell.com.rit.Home.HomeActivity;
import medicell.com.rit.Login.LoginActivity;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.R;
import medicell.com.rit.Utilities.BottomNavigationViewHelper;

/**
 * Created by Swaroop on 10-01-2018.
 */

public class Extra extends AppCompatActivity {

    private static final int ACTIVITY_NUM = 3;
    private Context mContext = Extra.this;

    private static final String TAG = "Extras";
   TextView text1, text2, text3,text4,text5,text6,text7;
   ImageButton button2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.other);

       text1 = findViewById(R.id.t2);
       text2 = findViewById(R.id.t3);
       text3 = findViewById(R.id.t4);
        text4=  findViewById(R.id.timetable);
//        text5 = findViewById(R.id.t5);
        text6 = findViewById(R.id.t6);
        text7 = findViewById(R.id.t10);


       button2= findViewById(R.id.imgbtn1);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Extra.this, Notifications.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);

            }
        });

      text1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.d(TAG, "onClick: navigating to about us screen");
                Intent intent = new Intent(Extra.this, Calender.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

       text2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to calender screen");
                Intent intent = new Intent(Extra.this, Elibrary.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

     text3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to Elibrary screen");
                Intent intent = new Intent(Extra.this, feedback.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

        text4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to feedback screen");
                Intent intent = new Intent(Extra.this,Timetable.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });



//        text5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d(TAG, "onClick: navigating to feedback screen");
//                Intent intent = new Intent(Extra.this,Settings.class);
//                startActivity(intent);
//                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
//            }
//        });

        text6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to contact screen");
                Intent intent = new Intent(Extra.this, About.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

        text7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to Login screen");
                Intent intent = new Intent(Extra.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

        setupBottomNavigationView();

    }
    private void setupBottomNavigationView(){
        Log.d(TAG, "setupBottomNavigationView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(mContext, this,bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);
    }

}
