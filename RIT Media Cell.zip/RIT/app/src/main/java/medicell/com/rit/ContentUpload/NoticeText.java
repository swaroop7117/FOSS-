package medicell.com.rit.ContentUpload;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import medicell.com.rit.R;
import medicell.com.rit.extras.Elibrary;
import medicell.com.rit.extras.Extra;

/**
 * Created by Swaroop on 12-01-2018.
 */

public class NoticeText extends AppCompatActivity {

    Button SubmitButton ;

    EditText NameEditText, LinkText;

    // Declaring String variable ( In which we are storing firebase server URL ).
    public static final String Firebase_Server_URL = "https://mediacellrit-20899.firebaseio.com/";
    // Declaring String variables to store name & phone number get from EditText.
    String NameHolder, NumberHolder;
    Firebase firebase;
    ImageButton button;
    DatabaseReference databaseReference;

    // Root Database Name for Firebase Database.
    public static final String Database_Path = "Notice_data";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.noticetext);

        Firebase.setAndroidContext(NoticeText.this);
        firebase = new Firebase(Firebase_Server_URL);
        databaseReference = FirebaseDatabase.getInstance().getReference(Database_Path);
        SubmitButton = findViewById(R.id.upb1);
        NameEditText = findViewById(R.id.noticedes);
        LinkText = findViewById(R.id.doclink);
        button= findViewById(R.id.imgbtn17);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(NoticeText.this, Admin.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        SubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                textdetail t1 = new textdetail();

                GetDataFromEditText();

                // Adding name into class function object.
                t1.setTextName(NameHolder);

                // Adding phone number into class function object.
                t1.setTextdata(NumberHolder);

                // Getting the ID from firebase database.
                String StudentRecordIDFromServer = databaseReference.push().getKey();

                // Adding the both name and number values using student details class object using ID.
                databaseReference.child(StudentRecordIDFromServer).setValue(t1);

                // Showing Toast message after successfully data submit.
                Toast.makeText(NoticeText.this,"Data Inserted Successfully into Firebase Database", Toast.LENGTH_LONG).show();

            }
        });

    }

    public void GetDataFromEditText(){

        NameHolder = NameEditText.getText().toString().trim();

        NumberHolder = LinkText.getText().toString().trim();

    }
}
