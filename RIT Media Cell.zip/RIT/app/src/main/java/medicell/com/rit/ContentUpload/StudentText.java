//package medicell.com.rit.ContentUpload;
//
//import android.app.Activity;
//import android.app.ProgressDialog;
//import android.content.ContentResolver;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.graphics.Bitmap;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.provider.MediaStore;
//import android.provider.Settings;
//import android.support.annotation.NonNull;
//import android.support.annotation.Nullable;
//import android.support.v4.content.ContextCompat;
//import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.ContentFrameLayout;
//import android.util.AndroidException;
//import android.util.Log;
//import android.view.View;
//import android.webkit.MimeTypeMap;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageButton;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.google.android.gms.tasks.OnFailureListener;
//import com.google.android.gms.tasks.OnSuccessListener;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.storage.FirebaseStorage;
//import com.google.firebase.storage.OnProgressListener;
//import com.google.firebase.storage.StorageReference;
//import com.google.firebase.storage.UploadTask;
//import com.nostra13.universalimageloader.core.display.BitmapDisplayer;
//
//import org.w3c.dom.Text;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.sql.Ref;
//
//import medicell.com.rit.ImageUpload.Constants;
//import medicell.com.rit.ImageUpload.ImageUpload;
//import medicell.com.rit.ImageUpload.TextUpload;
//import medicell.com.rit.Manifest;
//import medicell.com.rit.R;
//
//import static medicell.com.rit.ContentUpload.StudentImage.REQUEST_CODE;
//
///**
// * Created by Swaroop on 12-01-2018.
// */
//
//public class StudentText extends AppCompatActivity {
//
//    final static int REQUEST_CODE = 1;
//    static final int READ_BLOCK_SIZE = 100;
//    private static final String TAG = "Text";
//    File uploadedFile=null;
//
//    private EditText txtName;
//    private TextView m2;
//
//    ImageButton button;
//    Button button2, button3;
//
//    public static final String FB_STORAGE_PATH1 = "text/";
//    public static final String FB_DATABASE_PATH1 = "text";
//
//    private StorageReference mStorageRef;
//    private DatabaseReference mDatabaseRef;
//
//
//    private Uri txt;
//
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.studenttext);
//
//        mStorageRef = FirebaseStorage.getInstance().getReference();
//        mDatabaseRef = FirebaseDatabase.getInstance().getReference(FB_DATABASE_PATH1);
//
//        button = (ImageButton) findViewById(R.id.imgbtn17);
//        button2 = (Button) findViewById(R.id.ob);
//        button3 = findViewById(R.id.cb2);
//
//        txtName = findViewById(R.id.studtext3);
//         m2 = findViewById(R.id.studtext4);
//
//        // String description = m.getText().toString();
//        //String text = m2.getText().toString();
//
//
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(StudentText.this, Admin.class);
//                startActivity(intent);
//                finishAffinity();
//            }
//        });
//
//        button2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//                    Intent intent = new Intent();
//                    intent.addCategory(Intent.CATEGORY_OPENABLE);
//                    intent.setType("text/plain");
//                    intent.setAction(Intent.ACTION_GET_CONTENT);
//                    startActivityForResult(Intent.createChooser(intent, "Select File"), REQUEST_CODE);
//
//
//
//
//            }
//        });
//
//        button3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                StorageReference ref = mStorageRef.child(FB_STORAGE_PATH1 + System.currentTimeMillis() + "."+ getImageExt(txt));
////                ref.s(m2.getText().toString())
////
////
//            }
//
////                final ProgressDialog dialog = new ProgressDialog(StudentText.this);
////                dialog.setTitle("Uploading Text");
////                dialog.show();
////
////                //Get the storage reference
////                StorageReference ref = mStorageRef.child(FB_STORAGE_PATH1 + System.currentTimeMillis() + "."+ getImageExt(txt));
////
////                //Add file to reference
////
////                ref.putFile(txt).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
////                    @Override
////                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
////
////
////                        //Dimiss dialog when success
////                        dialog.dismiss();
////                        //Display success toast msg
////                        Toast.makeText(getApplicationContext(), "Text file uploaded", Toast.LENGTH_SHORT).show();
////                        TextUpload textUpload = new TextUpload(txtName.getText().toString(), taskSnapshot.getDownloadUrl().toString());
////
////                        //Save image info in to firebase database
////                        String uploadId = mDatabaseRef.push().getKey();
////                        mDatabaseRef.child(uploadId).setValue(textUpload);
////
////                    }
////                })
////                        .addOnFailureListener(new OnFailureListener() {
////                            @Override
////                            public void onFailure(@NonNull Exception e) {
////
////                                //Dimiss dialog when error
////                                dialog.dismiss();
////                                //Display err toast msg
////                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
////                            }
////                        })
////                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
////
////                            @Override
////                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
////
////                                //Show upload progress
////
////                                double progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
////                                dialog.setMessage("Uploaded " + (int) progress + "%");
////                            }
////                        });
//
//
//
//
////                String filename = txtName.getText().toString();
////                String filecontent = m2.getText().toString();
////                String fname=filename;
////
////                FileOperations fop = new FileOperations();
////                fop.write(filename, filecontent);
////                if(fop.write(filename, filecontent)){
////
////                    Toast.makeText(getApplicationContext(), filename+".txt created", Toast.LENGTH_SHORT).show();
////                    File file = null;
////                    try {
////                        file = File.createTempFile(fname, "txt");
////                    } catch( IOException e ) {
////
////                    }
////                    UploadTask uploadTask = mStorageRef.putFile(Uri.fromFile(file));
////                }else{
////                    Toast.makeText(getApplicationContext(), "I/O error", Toast.LENGTH_SHORT).show();
////
////                }
//
//
//
//        });
//
//    }
//
////    private void readFile() throws IOException {
////
////        uploadedString = new StringBuilder();
////        BufferedReader reader = new BufferedReader(new FileReader(uploadedFile));
////        String line;
////        while ((line = reader.readLine()) != null) {
////
////            uploadedString.append(line);
////            uploadedString.append('\n');
////        }
////        Log.i("Uploaded successfully: ", uploadedString.toString());
////        reader.close();
////    }
//
//
//
////    @Override
////    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
////
////        if (resultCode == Activity.RESULT_OK) {
////            if (data == null) {
////                return;
////            } else {
////                Uri uri = data.getData();
////               File uploadedFile = new File(uri.getPath());
////                try {
////                    readFile();
////                } catch (IOException e) {
////                    e.printStackTrace();
////                }
////            }
////        } else {
////            return;
////        }
////    }
//
////    @Override
////    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
////        super.onActivityResult(requestCode, resultCode, data);
////
////        if (requestCode == Activity.RESULT_OK) {
////            if (resultCode == RESULT_OK) {
////                // User pick the file
////                try {
////                    txt = data.getData();
////                    String fileContent = readTextFile(txt);
////                    m2.setText(fileContent);
////                }catch(Exception e){}
////                //Toast.makeText(this, fileContent, Toast.LENGTH_LONG).show();
////            } else {
////                Log.i(TAG, data.toString());
////          }
////        }
////    }
////        if (resultCode == Activity.RESULT_OK) {
////            if (data == null) {
////                return;
////            } else {
////                Uri uri = data.getData();
////                 uploadedFile = new File(uri.getPath());
////                try {
////                    readFile();
////                } catch (IOException e) {
////                    e.printStackTrace();
////                }
////            }
////        } else {
////            return;
////        }
////    }
////    private void readFile() throws IOException {
////
////        StringBuilder uploadedString = new StringBuilder();
////        BufferedReader reader = new BufferedReader(new FileReader(uploadedFile));
////        String line;
////        while ((line = reader.readLine()) != null) {
////
////            uploadedString.append(line);
////            uploadedString.append('\n');
////
////        }
////        m2.setText(uploadedString);
////        Log.i("Uploaded successfully: ", uploadedString.toString());
////        reader.close();
////    }
//
////    private String readTextFile(Uri uri) throws Exception{
////        BufferedReader reader = null;
////        StringBuilder builder = new StringBuilder();
////       try {
////            FileInputStream fileIn=openFileInput("abc.txt");
////            InputStreamReader InputRead= new InputStreamReader(fileIn);
////
////            char[] inputBuffer= new char[READ_BLOCK_SIZE];
////            String s="";
////            int charRead;
////
////            while ((charRead=InputRead.read(inputBuffer))>0) {
////                // char to string conversion
////                String readstring=String.copyValueOf(inputBuffer,0,charRead);
////                s +=readstring;
////            }
////            InputRead.close();
////        try {
////            reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri)));
////            String line ="";
////
////            while ((line = reader.readLine()) != null) {
////                builder.append(line);
////            }
////
////        } catch (IOException e) {
////            e.printStackTrace();
////        } finally {
////            if (reader != null){
////                try {
////
////                    reader.close();
////                } catch (IOException e) {
////                    e.printStackTrace();
////                }
////            }
////        }
////        return builder.toString();
////
////    }
//
////    public String getImageExt(Uri uri) {
////        ContentResolver contentResolver = getContentResolver();
////        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
////        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
////    }
//
////    protected void uploadfile() {
////        File file = null;
////        try {
////            file = File.createTempFile("file", "txt");
////        } catch (IOException e) {
////
////        }
////        StorageReference ref = mStorageRef.child(FB_STORAGE_PATH1 + System.currentTimeMillis() + "."+ getImageExt(txt));
////        UploadTask uploadTask = ref.putFile(Uri.fromFile(file));
////    }
////
//}

package medicell.com.rit.ContentUpload;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import medicell.com.rit.R;

/**
 * Created by Swaroop on 24-01-2018.
 */

public class StudentText extends AppCompatActivity {

    Button SubmitButton ;
    ImageButton button;

    EditText NameEditText, PhoneNumberEditText;

    // Declaring String variable ( In which we are storing firebase server URL ).
    public static final String Firebase_Server_URL = "https://mediacellrit-20899.firebaseio.com/";

    // Declaring String variables to store name & phone number get from EditText.
    String NameHolder, NumberHolder;

    Firebase firebase;

    DatabaseReference databaseReference;

    // Root Database Name for Firebase Database.
    public static final String Database_Path = "Text_data";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studenttext);

        Firebase.setAndroidContext(StudentText.this);

        firebase = new Firebase(Firebase_Server_URL);

        databaseReference = FirebaseDatabase.getInstance().getReference(Database_Path);

        SubmitButton = findViewById(R.id.cb2);

        NameEditText = findViewById(R.id.studtext3);

        button= findViewById(R.id.imgbtn17);

        PhoneNumberEditText = findViewById(R.id.studtext4);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(StudentText.this, Admin.class);
                startActivity(intent);
                finishAffinity();
            }
        });


        SubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                textdetail t1 = new textdetail();

                GetDataFromEditText();

                // Adding name into class function object.
                t1.setTextName(NameHolder);

                // Adding phone number into class function object.
                t1.setTextdata(NumberHolder);

                // Getting the ID from firebase database.
                String StudentRecordIDFromServer = databaseReference.push().getKey();

                // Adding the both name and number values using student details class object using ID.
                databaseReference.child(StudentRecordIDFromServer).setValue(t1);

                // Showing Toast message after successfully data submit.
                Toast.makeText(StudentText.this,"Uploaded Successfully...", Toast.LENGTH_LONG).show();

                NameEditText.setText("");
                PhoneNumberEditText.setText("");
            }
        });

    }

    public void GetDataFromEditText(){

        NameHolder = NameEditText.getText().toString().trim();

        NumberHolder = PhoneNumberEditText.getText().toString().trim();

    }
}

