package medicell.com.rit.Home;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.StackView;

import com.airbnb.lottie.LottieAnimationView;
import com.github.clans.fab.FloatingActionMenu;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import medicell.com.rit.ContentUpload.StudentImage;
import medicell.com.rit.ContentUpload.StudentText;

import medicell.com.rit.ImageFetch.RecyclerViewAdapter;
import medicell.com.rit.ImageUpload.ImageUpload;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.PostReq.MailActivity;
import medicell.com.rit.R;
import medicell.com.rit.Utilities.BottomNavigationViewHelper;

/**
 * Created by Swaroop on 08-01-2018.
 */

public class HomeActivity extends AppCompatActivity {

    private static final String TAG ="HomeActivity" ;
    protected FloatingActionMenu floatingActionMenu;
    private static final int ACTIVITY_NUM = 0;
    private Context mContext = HomeActivity.this;
    private static int POST_DELAYED=1500;

    private RecyclerView mRecyclerview;
    private FrameLayout mFrameLayout;
    private RelativeLayout mRelativeLayout;
    protected ImageButton button2;

    FirebaseStorage storage;
    private ImageView mImageView;
    private StorageReference mStorage;

    public SwipeRefreshLayout swipeRefreshLayout;


   //  SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.refresh);
    // Creating DatabaseReference.
    DatabaseReference databaseReference;

    // Creating RecyclerView.
    RecyclerView recyclerView;

    // Creating RecyclerView.Adapter.
    RecyclerView.Adapter adapter ;

    // Creating Progress dialog
    ProgressDialog progressDialog;

    // Creating List of ImageUploadInfo class.
    List<ImageUpload> list = new ArrayList<>();
    List<ImageUpload> list2= new ArrayList<>();


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mStorage = FirebaseStorage.getInstance().getReference();

        //LottieAnimationView animationView= findViewById(R.id.image_heart1);
         ImageView i=findViewById(R.id.post_image2);
        // final ImageView a=findViewById(R.id.image_heart_red1);

       // mRelativeLayout = (RelativeLayout) findViewById(R.id.relLayoutParent);
        //mImageView = (ImageView) findViewById(R.id.post_image);

        swipeRefreshLayout= findViewById(R.id.refresh);
        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorPrimary));

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView100);

        // Setting RecyclerView size true.
        recyclerView.setHasFixedSize(true);

        // Setting RecyclerView layout as LinearLayout.
        recyclerView.setLayoutManager(new LinearLayoutManager(HomeActivity.this));
        RecyclerView.SmoothScroller smoothScroller = new LinearSmoothScroller(mContext) {
            @Override protected int getVerticalSnapPreference() {
                return LinearSmoothScroller.SNAP_TO_START;
            }
        };

        // Assign activity this to progress dialog.

        progressDialog = new ProgressDialog(HomeActivity.this);

        // Setting up message in Progress dialog.
        progressDialog.setMessage("Loading...");

        // Showing progress dialog.
        progressDialog.show(); 

        // Setting up Firebase image upload folder path in databaseReference.
        // The path is already defined in MainActivity.
        databaseReference = FirebaseDatabase.getInstance().getReference(StudentImage.FB_DATABASE_PATH);

        floatingActionMenu = (FloatingActionMenu) findViewById(R.id.material_design_android_floating_action_menu);
        button2 = (ImageButton) findViewById(R.id.imgbtn1);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setEnabled(true);
                adapter.notifyDataSetChanged();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setEnabled(false);
                    }

                },POST_DELAYED);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, Notifications.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);

            }
        });


        floatingActionMenu.setOnMenuButtonClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, MailActivity.class);
                startActivity(intent);
            }
        });

//        swipeRefreshLayout.setColorSchemeResources(R.color.refresh,R.color.refresh1,R.color.refresh2);
//        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                swipeRefreshLayout.setRefreshing(true);
//                (new Handler()).postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        swipeRefreshLayout.setRefreshing(false);
//
//                        int min = 65;
//                        int max = 95;
//                        Random random = new Random();
//                        int i =random.nextInt(max-min+1)+min;
//
//
//                    }
//                },3000);
//            }
//        });

        getData();
        setupBottomNavigationView();
        //  GetDataFirebase();

    }

    public void getData(){

        // Adding Add Value Event Listener to databaseReference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                    ImageUpload imageUpload = postSnapshot.getValue(ImageUpload.class);

                    list.add(imageUpload);


                }
                int cnt=list.size();

                for(int i=cnt;i>0;i--)
                {
                    list2.add(list.get(i-1));
                }


                adapter = new RecyclerViewAdapter(getApplicationContext(), list2);
                recyclerView.setAdapter(adapter);

                // Hiding the progress dialog.
                progressDialog.dismiss();
                swipeRefreshLayout.setEnabled(true);
            }



            @Override
            public void onCancelled(DatabaseError databaseError) {

                // Hiding the progress dialog.
                progressDialog.dismiss();

            }

        });

    }



    public void hideLayout(){
        Log.d(TAG, "hideLayout: hiding layout");
        mRelativeLayout.setVisibility(View.GONE);
        mFrameLayout.setVisibility(View.VISIBLE);
    }

    private void setupBottomNavigationView(){
        Log.d(TAG, "setupBottomNavigationView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(mContext, this,bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);

    }

}
