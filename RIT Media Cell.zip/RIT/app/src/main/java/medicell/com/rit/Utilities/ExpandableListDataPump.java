package medicell.com.rit.Utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class ExpandableListDataPump {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();

        List<String> a = new ArrayList<String>();
        a.add("https://saemobilus.sae.org/search/");

        List<String> b = new ArrayList<String>();
        b.add("http://www.asmedl.org");

        List<String> c = new ArrayList<String>();
        c.add("http://ascelibrary.org/journals/alljournal titles");

        List<String> d = new ArrayList<String>();
        d.add("http://www.springerlink.com");
        d.add("http://digital-library.theiet.org/content/journals");

        List<String> e = new ArrayList<String>();
        e.add("http://www.springerlink.com");
        e.add("http://digital-library.theiet.org/content/journals");

        List<String> f = new ArrayList<String>();
        f.add("http://www.springerlink.com");
        f.add("http://digital-library.theiet.org/content/journals");

        List<String> g = new ArrayList<String>();
        g.add("http://digital-library.theiet.org/content/journals");

        List<String> h= new ArrayList<String>();
        h.add("http://search.ebscohost.com");
        h.add("http://www.jgateplus.com");

        List<String> i = new ArrayList<String>();
        i.add("https://ndl.iitkgp.ac.in/");
        i.add("http://www.springerlink.com");
        i.add("http://digital-library.theiet.org/content/books");
        i.add("http://www.sciencedirect.com");

        List<String> j = new ArrayList<String>();
        j.add("http://172.22.4.83:8090/ ");
        j.add("http://172.22.4.66:8080/gate/");
        j.add("http://172.22.28.10/jspui/");

        expandableListDetail.put("Automobile", a);
        expandableListDetail.put("Mechanical", b);
        expandableListDetail.put("Civil", c);
        expandableListDetail.put("Computer Engineering", d);
        expandableListDetail.put("Electrical", e);
        expandableListDetail.put("E&TC", f);
        expandableListDetail.put("IT", g);
        expandableListDetail.put("Management", h);
        expandableListDetail.put("All", i);
        expandableListDetail.put("Campus Only Links", j);
        return expandableListDetail;
    }
}
