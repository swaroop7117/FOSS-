package medicell.com.rit.ImageUpload;

/**
 * Created by Belal on 8/25/2017.
 */

public class Constants {

}
