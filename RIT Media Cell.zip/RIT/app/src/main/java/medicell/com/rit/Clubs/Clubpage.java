package medicell.com.rit.Clubs;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.github.clans.fab.FloatingActionMenu;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import java.util.ArrayList;
import java.util.List;

import medicell.com.rit.ContentUpload.StudentImage;
import medicell.com.rit.Home.HomeActivity;
import medicell.com.rit.ImageFetch.RecyclerViewAdapter;
import medicell.com.rit.ImageFetch.RecyclerViewAdapter4;
import medicell.com.rit.ImageUpload.ClubsUpload;
import medicell.com.rit.ImageUpload.ImageUpload;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.PostReq.MailActivity;
import medicell.com.rit.R;
import medicell.com.rit.Utilities.BottomNavigationViewHelper;

/**
 * Created by Swaroop on 29-01-2018.
 */

public class Clubpage extends AppCompatActivity {
    private static final String TAG = "club";
    protected FloatingActionMenu floatingActionMenu;
    private static final int ACTIVITY_NUM = 2;
    private Context mContext = Clubpage.this;

    private RecyclerView mRecyclerview;
    private FrameLayout mFrameLayout;
    private RelativeLayout mRelativeLayout;
    protected ImageButton button2;

    FirebaseStorage storage;
    private ImageView mImageView;
    private StorageReference mStorage;
    public static final String Database_Path = "clubimages";


    // Creating DatabaseReference.
    DatabaseReference databaseReference;

    // Creating RecyclerView.
    RecyclerView recyclerView;

    // Creating RecyclerView.Adapter.
    RecyclerView.Adapter adapter;

    // Creating Progress dialog
    ProgressDialog progressDialog;

    // Creating List of ImageUploadInfo class.
    List<ClubsUpload> list = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.collegeclubs);

        mStorage = FirebaseStorage.getInstance().getReference();

        // mRelativeLayout = (RelativeLayout) findViewById(R.id.relLayoutParent);
        //mImageView = (ImageView) findViewById(R.id.post_image);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView10);

        // Setting RecyclerView size true.
        recyclerView.setHasFixedSize(true);

        // Setting RecyclerView layout as LinearLayout.
        recyclerView.setLayoutManager(new LinearLayoutManager(Clubpage.this));

        // Assign activity this to progress dialog.

        progressDialog = new ProgressDialog(Clubpage.this);

        // Setting up message in Progress dialog.
        progressDialog.setMessage("Loading...");

        // Showing progress dialog.
        progressDialog.show();

        // Setting up Firebase image upload folder path in databaseReference.
        // The path is already defined in MainActivity.
        databaseReference = FirebaseDatabase.getInstance().getReference(Clubpage.Database_Path);

       // floatingActionMenu = (FloatingActionMenu) findViewById(R.id.material_design_android_floating_action_menu);
        button2 = (ImageButton) findViewById(R.id.imgbtn1);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Clubpage.this, Notifications.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);

            }
        });


        // Adding Add Value Event Listener to databaseReference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                    ClubsUpload clubsUpload = postSnapshot.getValue(ClubsUpload.class);

                    list.add(clubsUpload);


                }

                adapter = new RecyclerViewAdapter4(getApplicationContext(), list);
                recyclerView.setAdapter(adapter);

                // Hiding the progress dialog.
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                // Hiding the progress dialog.
                progressDialog.dismiss();

            }
        });


        setupBottomNavigationView();
        //  GetDataFirebase();

    }

    public void count() {
        adapter.getItemCount();
    }

    public void hideLayout() {
        Log.d(TAG, "hideLayout: hiding layout");
        mRelativeLayout.setVisibility(View.GONE);
        mFrameLayout.setVisibility(View.VISIBLE);
    }

    private void setupBottomNavigationView() {
        Log.d(TAG, "setupBottomNavigationView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(mContext, this, bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);

    }

}