package medicell.com.rit.ContentUpload;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import medicell.com.rit.Clubs.Addclubs;
import medicell.com.rit.Login.LoginActivity;
import medicell.com.rit.R;

/**
 * Created by Swaroop on 09-01-2018.
 */

public class Admin extends AppCompatActivity {

    private static final String TAG = "Admin";
    TextView text1, text2, text3,text4, text5, text6;
    ImageButton btn;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        text1 = findViewById(R.id.tb1);
        text2 = findViewById(R.id.tb2);
        text3 = findViewById(R.id.club);
        //text4 = findViewById(R.id.tb4);
     //  text5 = findViewById(R.id.tb5);
         text6 = findViewById(R.id.tb6);
        TextView t1= findViewById(R.id.text_txt5);
        final String s1="Content Upload";
        t1.setText(s1);

        btn=(ImageButton) findViewById(R.id.imgbtn14);

        text1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to student image upload screen");
                Intent intent = new Intent(Admin.this, StudentImage.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

        text2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to student text upload screen");
                Intent intent = new Intent(Admin.this, StudentText.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        });

        text3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to College Image upload screen");
                Intent intent = new Intent(Admin.this, Addclubs.class);
                startActivity(intent);
            }
        });

     /*   text4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to College Text upload screen");
                Intent intent = new Intent(Admin.this, CollegeText.class);
                startActivity(intent);
            }
        });*/

//        text5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d(TAG, "onClick: navigating to Notice Image Upload screen");
//                Intent intent = new Intent(Admin.this, NoticeImage.class);
//                startActivity(intent);
//            }
//        });
//
        text6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: navigating to Notice Text Upload screen");
                Intent intent = new Intent(Admin.this, NoticeText.class);
                startActivity(intent);
            }
        });

        setupFirebaseAuth();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent=new Intent(Admin.this,LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
                finishAffinity();
            }
        });

    }

    private void setupFirebaseAuth(){
        Log.d(TAG, "setupFirebaseAuth: setting up firebase auth.");

        mAuth = FirebaseAuth.getInstance();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();

                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };
    }


}
