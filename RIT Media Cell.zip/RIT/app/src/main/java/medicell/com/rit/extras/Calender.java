package medicell.com.rit.extras;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import medicell.com.rit.Home.HomeActivity;
import medicell.com.rit.Notifications.Notifications;
import medicell.com.rit.R;

/**
 * Created by Swaroop on 10-01-2018.
 */

public class Calender extends AppCompatActivity {

    private static final String TAG ="Calender" ;
    ImageButton button;
    TextView t1,t2,t3;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calender);

        button=(ImageButton) findViewById(R.id.imgbtn14);
        t1=(TextView) findViewById(R.id.cal1);
        t2=(TextView) findViewById(R.id.cal2);
        t3=(TextView) findViewById(R.id.cal3);

        TextView t1= findViewById(R.id.text_txt5);
        final String s1="Calender";
        t1.setText(s1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Calender.this, Extra.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
                finishAffinity();
            }
        });

       t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = "https://drive.google.com/open?id=0B6_OI71SWLgcaDhuY1B5eHJfS0wxQUNZWlVCYWxGZ0o3TUI4";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });

        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=0B6_OI71SWLgcMGlXWkdnUVNxYUZ6ZG1pbXVpN3Bqd3dMckZN";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://drive.google.com/open?id=0B6_OI71SWLgcdDc3UTRETWJKc3NWVm04OV9ERS1SQmxaUnVF";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });
    }
}
